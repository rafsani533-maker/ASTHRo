# ASTHRo V1 — Starter Website

This package uses the uploaded ASTHRo logo and the uploaded anime cover images.

## Included
- White + Red + Gold ASTHRo theme
- ASTHRo logo + rounded display typography
- Anime catalog with:
  - Attack on Titan
  - Bleach
  - Lord of Mysteries
  - Re:Zero
  - Mushoku Tensei
  - Witch Hat Atelier
  - Chainsaw Man: Reze Arc
  - The Eminence in Shadow
- Search overlay
- Anime details modal
- Trending section
- Novel Library with re:think chapter reader
- Login UI placeholder
- Private Developer Panel prototype
- Episode metadata entry UI
- Role/permission model shown in the Developer Panel

## Run locally
Open `index.html` in a browser.

Open `admin.html` for the Developer Panel prototype.

## Important
This is the frontend V1. It does NOT yet provide secure real authentication or permanent public video uploads.

For the real ASTHRo platform, connect:
1. Firebase Authentication
2. Firestore
3. Firebase Storage (or a suitable video/CDN storage provider)
4. Server-side/security rules for OWNER vs AUTHOR vs READER
5. Hosting + custom domain
6. sitemap.xml + Google Search Console

Do not put copyrighted anime videos online unless you have the right/license/permission to distribute them.

The `reference-font-logo.jpeg` is included only as the user's visual reference for typography.
